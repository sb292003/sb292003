
import React, { useState, useMemo } from 'react';
import { MOCK_SCHOLARSHIPS } from '../constants';
import { Calendar, Award, Globe, ExternalLink, Filter, Search, Tag } from 'lucide-react';

export const ScholarshipView: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('All Countries');

  const countries = useMemo(() => {
    const list = new Set<string>();
    MOCK_SCHOLARSHIPS.forEach(s => s.eligibleCountries.forEach(c => list.add(c)));
    return ['All Countries', ...Array.from(list).sort()];
  }, []);

  const filteredScholarships = useMemo(() => {
    return MOCK_SCHOLARSHIPS.filter(s => {
      const matchesSearch = s.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            s.platform.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCountry = selectedCountry === 'All Countries' || s.eligibleCountries.includes(selectedCountry);
      return matchesSearch && matchesCountry;
    });
  }, [searchQuery, selectedCountry]);

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col gap-1 mb-4">
        <h2 className="text-2xl font-bold text-slate-900">Scholarships & Grants</h2>
        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Accelerate Your Academic Journey</p>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input 
            type="text"
            placeholder="Search programs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-2xl shadow-sm focus:ring-2 focus:ring-blue-500 outline-none transition-all"
          />
        </div>
        <div className="relative">
          <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <select
            value={selectedCountry}
            onChange={(e) => setSelectedCountry(e.target.value)}
            className="w-full pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-2xl shadow-sm appearance-none focus:ring-2 focus:ring-blue-500 outline-none transition-all"
          >
            {countries.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredScholarships.map((s) => (
          <div key={s.id} className="bg-white border rounded-2xl p-6 shadow-sm hover:shadow-md transition-all border-l-4 border-l-blue-600">
            <div className="flex flex-col md:flex-row justify-between gap-4">
              <div className="space-y-3 flex-1">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 bg-blue-50 text-blue-600 text-[10px] font-black uppercase rounded">{s.category} Funding</span>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{s.platform}</span>
                </div>
                
                <h3 className="text-xl font-bold text-slate-900">{s.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  {s.description}
                </p>

                <div className="flex flex-wrap gap-4 pt-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-500">
                    <Award className="w-4 h-4 text-blue-500" />
                    {s.amount}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-500">
                    <Calendar className="w-4 h-4 text-orange-500" />
                    Deadline: {s.deadline}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-500">
                    <Globe className="w-4 h-4 text-green-500" />
                    {s.eligibleCountries.join(', ')}
                  </div>
                </div>
              </div>

              <div className="flex md:flex-col justify-end items-end gap-2">
                <a 
                  href={s.link} 
                  target="_blank"
                  className="w-full md:w-32 bg-blue-600 text-white text-center py-2.5 rounded-xl font-bold text-sm hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20"
                >
                  Apply <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        ))}

        {filteredScholarships.length === 0 && (
          <div className="py-12 text-center text-slate-400 font-medium">
            No scholarships found for these filters.
          </div>
        )}
      </div>
    </div>
  );
};

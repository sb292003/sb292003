
import React, { useState } from 'react';
import { MessageCircle, Share2, Bookmark, Sparkles, ExternalLink, MoreHorizontal, GraduationCap, Link2 } from 'lucide-react';
import { ResearchPost } from '../types';
import { summarizeResearch } from '../services/geminiService';

interface PostCardProps {
  post: ResearchPost;
}

export const PostCard: React.FC<PostCardProps> = ({ post }) => {
  const [endorsed, setEndorsed] = useState(false);
  const [citationCount, setCitationCount] = useState(post.citations);
  const [isCiting, setIsCiting] = useState(false);
  const [aiSummary, setAiSummary] = useState(post.aiSummary || '');
  const [loadingAI, setLoadingAI] = useState(false);

  const handleGenerateSummary = async () => {
    if (aiSummary) return;
    setLoadingAI(true);
    const summary = await summarizeResearch(post.title, post.abstract);
    setAiSummary(summary);
    setLoadingAI(false);
  };

  const handleCite = () => {
    setIsCiting(true);
    // Simulate a citation process with vibration feedback if available
    if (navigator.vibrate) navigator.vibrate(50);
    setTimeout(() => {
      setCitationCount(prev => prev + 1);
      setIsCiting(false);
    }, 800);
  };

  return (
    <div className="bg-white border rounded-2xl overflow-hidden mb-6 shadow-sm hover:shadow-md transition-shadow active:scale-[0.99] md:active:scale-100">
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src={post.authorAvatar} alt={post.authorName} className="w-10 h-10 rounded-full object-cover border" />
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="font-semibold text-sm leading-tight text-slate-900">{post.authorName}</h3>
              <div className="bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded text-[10px] font-bold uppercase">
                {post.authorRole}
              </div>
            </div>
            <p className="text-xs text-slate-500 uppercase font-medium tracking-wider">{post.field}</p>
          </div>
        </div>
        <button className="p-2 -mr-2 text-slate-400 hover:text-slate-600">
          <MoreHorizontal className="w-5 h-5" />
        </button>
      </div>

      {/* Image / Graphic */}
      <div className="relative aspect-video bg-slate-100 flex items-center justify-center">
        <img src={post.imageUrl} alt={post.title} className="w-full h-full object-cover" loading="lazy" />
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-2 py-1 rounded-md text-[10px] font-bold shadow-sm">
          FIGURE 1.2
        </div>
      </div>

      {/* Interactions */}
      <div className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-5">
            <button 
              onClick={() => {
                setEndorsed(!endorsed);
                if (!endorsed && navigator.vibrate) navigator.vibrate(20);
              }} 
              className={`flex items-center gap-1.5 transition-all active:scale-125 ${endorsed ? 'text-blue-600' : 'text-slate-700 hover:text-slate-900'}`}
              title="Endorse this work"
            >
              <GraduationCap className={`w-7 h-7 ${endorsed ? 'fill-blue-600' : ''}`} />
              <span className="text-sm font-bold">{post.endorsements + (endorsed ? 1 : 0)}</span>
            </button>
            <button 
              onClick={handleCite}
              disabled={isCiting}
              className={`flex items-center gap-1.5 transition-all active:scale-110 ${isCiting ? 'text-green-500' : 'text-slate-700 hover:text-slate-900'}`}
              title="Cite in your research"
            >
              <Link2 className={`w-7 h-7 ${isCiting ? 'animate-pulse' : ''}`} />
              <span className="text-sm font-bold">{citationCount}</span>
            </button>
            <button className="text-slate-700 hover:text-slate-900 active:scale-110" title="Discuss">
              <MessageCircle className="w-7 h-7" />
            </button>
            <button className="text-slate-700 hover:text-slate-900 active:scale-110" title="Share Abstract">
              <Share2 className="w-7 h-7" />
            </button>
          </div>
          <button className="p-1 text-slate-700 hover:text-slate-900 active:scale-110">
            <Bookmark className="w-7 h-7" />
          </button>
        </div>

        <div>
          <h2 className="font-bold text-lg text-slate-900 mb-1 leading-snug">{post.title}</h2>
          <p className="text-sm text-slate-600 line-clamp-3 italic leading-relaxed">
            "{post.abstract}"
          </p>
        </div>

        {/* AI Insight Section - Compact for Mobile */}
        <div className="mt-4 p-4 rounded-2xl bg-gradient-to-br from-blue-50/80 to-indigo-50/80 border border-blue-100 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-blue-700 text-[10px] font-bold uppercase tracking-widest">
              <Sparkles className="w-3.5 h-3.5" />
              Impact Insight
            </div>
            {!aiSummary && (
              <button 
                onClick={handleGenerateSummary}
                disabled={loadingAI}
                className="text-xs bg-blue-600 text-white px-3 py-1.5 rounded-full font-bold hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                {loadingAI ? '...' : 'Analyze'}
              </button>
            )}
          </div>
          {aiSummary && (
            <p className="text-sm text-slate-800 leading-relaxed font-medium">
              {aiSummary}
            </p>
          )}
        </div>

        <div className="flex items-center justify-between pt-2">
          <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{post.timestamp}</div>
          {post.doi && (
            <a 
              href={`https://doi.org/${post.doi}`} 
              target="_blank" 
              className="flex items-center gap-1 text-[10px] font-black text-blue-600 bg-blue-50 px-2 py-1 rounded hover:bg-blue-100 transition-colors"
            >
              <ExternalLink className="w-3 h-3" />
              DOI
            </a>
          )}
        </div>
      </div>
    </div>
  );
};

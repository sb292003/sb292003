
import React from 'react';
import { Home, Search, PlusSquare, UserRoundSearch, Bell, Compass, Microscope, LogOut, School, GraduationCap } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) void;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeTab, onTabChange }) => {
  const navItems = [
    { id: 'feed', icon: Home, label: 'Feed' },
    { id: 'explore', icon: Compass, label: 'Explore' },
    { id: 'universities', icon: School, label: 'Universities' },
    { id: 'scholarships', icon: GraduationCap, label: 'Scholarships' },
    { id: 'post', icon: PlusSquare, label: 'Publish' },
    { id: 'notifications', icon: Bell, label: 'Notifications' },
    { id: 'profile', icon: UserRoundSearch, label: 'Profile' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row pb-safe">
      {/* Sidebar - Desktop */}
      <nav className="hidden md:flex flex-col w-64 h-screen fixed left-0 border-r bg-white p-4 space-y-6">
        <div className="flex items-center gap-2 px-2 py-4 cursor-pointer" onClick={() => onTabChange('feed')}>
          <Microscope className="w-8 h-8 text-blue-600" />
          <span className="text-xl font-bold tracking-tight text-slate-900">SciLens</span>
        </div>

        <div className="flex-1 space-y-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl transition-all ${
                activeTab === item.id 
                  ? 'bg-blue-50 text-blue-600 font-semibold shadow-sm shadow-blue-500/10' 
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <item.icon className="w-6 h-6" strokeWidth={activeTab === item.id ? 2.5 : 2} />
              <span>{item.label}</span>
            </button>
          ))}
        </div>

        <div className="pt-4 border-t">
          <button className="flex items-center gap-3 w-full px-4 py-3 text-slate-600 hover:bg-red-50 hover:text-red-600 rounded-xl transition-all">
            <LogOut className="w-6 h-6" />
            <span>Logout</span>
          </button>
        </div>
      </nav>

      {/* Mobile Top Bar - Padded for status bar/notches */}
      <div className="md:hidden fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md border-b z-50 px-4 py-3 pt-safe flex justify-between items-center transition-all">
        <div className="flex items-center gap-2" onClick={() => onTabChange('feed')}>
          <Microscope className="w-7 h-7 text-blue-600" />
          <span className="text-lg font-bold">SciLens</span>
        </div>
        <div className="flex items-center gap-4">
            <Search className="w-5 h-5 text-slate-600" />
            <Bell className="w-5 h-5 text-slate-600" />
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 md:ml-64 mt-[calc(3.5rem+env(safe-area-inset-top))] md:mt-0 p-4 md:p-8 mb-[calc(4rem+env(safe-area-inset-bottom))] md:mb-0">
        <div className="max-w-2xl mx-auto scroll-area">
          {children}
        </div>
      </main>

      {/* Mobile Bottom Nav - Padded for home bar indicator */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-lg border-t z-50 flex justify-around items-center py-2 pb-safe shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)]">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={`p-3 rounded-xl transition-transform active:scale-95 ${activeTab === item.id ? 'text-blue-600' : 'text-slate-400'}`}
          >
            <item.icon className="w-6 h-6" strokeWidth={activeTab === item.id ? 2.5 : 2} />
          </button>
        ))}
      </nav>
    </div>
  );
};

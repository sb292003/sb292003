
import React, { useState } from 'react';
import { X, Loader2, Link2, Check, Chrome, GraduationCap } from 'lucide-react';
import { fetchExternalResearch } from '../services/geminiService';
import { ExternalPublication } from '../types';

interface ImportResearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (pub: ExternalPublication) => void;
}

export const ImportResearchModal: React.FC<ImportResearchModalProps> = ({ isOpen, onClose, onImport }) => {
  const [platform, setPlatform] = useState<'ORCID' | 'Scholar'>('ORCID');
  const [profileId, setProfileId] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<ExternalPublication[]>([]);
  const [hasSearched, setHasSearched] = useState(false);

  if (!isOpen) return null;

  const handleFetch = async () => {
    if (!profileId) return;
    setIsLoading(true);
    setHasSearched(true);
    const data = await fetchExternalResearch(platform, profileId);
    setResults(data);
    setIsLoading(false);
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-md" onClick={onClose}></div>
      <div className="relative bg-white w-full max-w-xl rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="p-8 border-b flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">Sync Lab Records</h2>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Connect external academic profiles</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
            <X className="w-6 h-6 text-slate-400" />
          </button>
        </div>

        <div className="p-8 space-y-6">
          <div className="flex gap-2 p-1.5 bg-slate-100 rounded-2xl">
            <button 
              onClick={() => setPlatform('ORCID')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-sm transition-all ${platform === 'ORCID' ? 'bg-white text-[#A6CE39] shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <div className={`w-5 h-5 flex items-center justify-center rounded-sm ${platform === 'ORCID' ? 'bg-[#A6CE39] text-white' : 'bg-slate-300 text-white'}`}>
                <span className="text-[10px] font-black">iD</span>
              </div>
              ORCID
            </button>
            <button 
              onClick={() => setPlatform('Scholar')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-sm transition-all ${platform === 'Scholar' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <Chrome className="w-5 h-5" />
              Google Scholar
            </button>
          </div>

          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Link2 className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="text"
                placeholder={platform === 'ORCID' ? '0000-0000-0000-0000' : 'Search Scholar ID / Name'}
                value={profileId}
                onChange={(e) => setProfileId(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-600 outline-none transition-all font-medium text-slate-900"
              />
            </div>
            <button 
              onClick={handleFetch}
              disabled={isLoading || !profileId}
              className="bg-slate-900 text-white px-8 rounded-2xl font-bold hover:bg-blue-600 transition-all disabled:opacity-50 shadow-xl shadow-slate-900/10"
            >
              {isLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : 'Fetch'}
            </button>
          </div>

          <div className="max-h-[350px] overflow-y-auto space-y-3 pr-2 scrollbar-hide">
            {isLoading ? (
              <div className="py-20 text-center flex flex-col items-center gap-4">
                <Loader2 className="w-12 h-12 text-blue-600 animate-spin" />
                <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Searching Scientific Repositories...</p>
              </div>
            ) : results.map((pub) => (
              <div key={pub.id} className="group bg-slate-50 border border-slate-100 p-5 rounded-3xl hover:border-blue-300 hover:bg-white transition-all">
                <div className="flex justify-between gap-4">
                  <div className="space-y-1.5 flex-1">
                    <h4 className="font-bold text-slate-900 leading-tight group-hover:text-blue-600 transition-colors">{pub.title}</h4>
                    <p className="text-xs text-slate-500 font-medium italic">{pub.authors.join(', ')}</p>
                    <div className="flex items-center gap-3 pt-1">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{pub.journal} • {pub.year}</span>
                    </div>
                  </div>
                  <button 
                    onClick={() => onImport(pub)}
                    className="shrink-0 w-12 h-12 bg-white border border-slate-200 rounded-full flex items-center justify-center text-slate-400 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all shadow-sm"
                  >
                    <Check className="w-6 h-6" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

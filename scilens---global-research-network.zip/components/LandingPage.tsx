
import React from 'react';
import { Microscope, Globe, GraduationCap, Zap, Users, ShieldCheck, ArrowRight, Share2, Sparkles } from 'lucide-react';

interface LandingPageProps {
  onJoin: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onJoin }) => {
  return (
    <div className="min-h-screen bg-white selection:bg-blue-100">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-lg z-[80] border-b">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-blue-600 rounded-lg">
              <Microscope className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900">SciLens</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-semibold text-slate-600">
            <a href="#features" className="hover:text-blue-600 transition-colors">Innovations</a>
            <a href="#impact" className="hover:text-blue-600 transition-colors">Global Impact</a>
            <a href="#institutions" className="hover:text-blue-600 transition-colors">Institutions</a>
          </div>
          <button 
            onClick={onJoin}
            className="bg-slate-900 text-white px-6 py-2 rounded-full text-sm font-bold hover:bg-blue-600 transition-all shadow-lg shadow-slate-900/10 active:scale-95"
          >
            Sign In
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        {/* Abstract Background Elements */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full -z-10 opacity-30">
          <div className="absolute top-20 left-10 w-64 h-64 bg-blue-400 rounded-full blur-[100px] animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-indigo-400 rounded-full blur-[120px]"></div>
        </div>

        <div className="max-w-4xl mx-auto px-6 text-center space-y-8">
          <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-600 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest animate-bounce">
            <Sparkles className="w-3.5 h-3.5" />
            The Future of Research is Visual
          </div>
          
          <h1 className="text-5xl md:text-7xl font-black text-slate-900 tracking-tighter leading-[1.1]">
            Where Science <span className="text-blue-600">Goes Viral</span>
          </h1>
          
          <p className="text-xl text-slate-600 max-w-2xl mx-auto font-medium leading-relaxed">
            The first professional social network for the global scientific community. Showcase breakthroughs, connect with peer investigators, and accelerate discovery through visual abstracts.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button 
              onClick={onJoin}
              className="w-full sm:w-auto bg-blue-600 text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-blue-700 transition-all shadow-xl shadow-blue-500/30 flex items-center justify-center gap-2 group"
            >
              Start Your Lab <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <div className="flex -space-x-3 items-center">
              {[1, 2, 3, 4].map(i => (
                <img key={i} src={`https://picsum.photos/seed/sci${i}/100/100`} className="w-10 h-10 rounded-full border-2 border-white object-cover" alt="Researcher" />
              ))}
              <div className="pl-6 text-sm font-bold text-slate-500 uppercase tracking-widest">
                25k+ Researchers Joined
              </div>
            </div>
          </div>
        </div>

        {/* Product Mockup */}
        <div className="mt-20 max-w-6xl mx-auto px-6">
          <div className="relative rounded-[2.5rem] border-8 border-slate-900 overflow-hidden shadow-2xl shadow-blue-500/20 bg-slate-50">
            <img src="https://images.unsplash.com/photo-1532187875605-186e6af83161?auto=format&fit=crop&q=80&w=2070" className="w-full h-auto object-cover opacity-20 absolute inset-0 blur-xl" alt="Lab environment" />
            <div className="relative p-8 md:p-12 space-y-12">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {/* Visual Posts Preview */}
                <div className="md:col-span-2 space-y-6">
                  <div className="bg-white border rounded-3xl p-6 shadow-xl space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-slate-100 border"></div>
                      <div className="space-y-1">
                        <div className="w-32 h-3 bg-slate-100 rounded"></div>
                        <div className="w-20 h-2 bg-slate-50 rounded"></div>
                      </div>
                    </div>
                    <div className="aspect-video bg-blue-50 rounded-2xl flex items-center justify-center border border-blue-100">
                       <Zap className="w-12 h-12 text-blue-200" />
                    </div>
                    <div className="space-y-2">
                       <div className="w-full h-4 bg-slate-100 rounded"></div>
                       <div className="w-2/3 h-4 bg-slate-50 rounded"></div>
                    </div>
                  </div>
                </div>
                {/* Stats Preview */}
                <div className="space-y-6">
                  <div className="bg-white border rounded-3xl p-6 shadow-xl text-center">
                    <div className="text-4xl font-black text-blue-600">4,502</div>
                    <div className="text-xs font-black text-slate-400 uppercase tracking-widest mt-2">Daily Breakthroughs</div>
                  </div>
                  <div className="bg-slate-900 rounded-3xl p-6 text-white shadow-xl">
                    <div className="flex items-center gap-2 mb-4">
                      <ShieldCheck className="w-5 h-5 text-green-400" />
                      <span className="text-xs font-bold uppercase tracking-widest">Verified Institution</span>
                    </div>
                    <p className="text-sm font-medium text-slate-300">SciLens connects with 800+ top universities globally.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Grid */}
      <section id="features" className="py-20 bg-slate-50">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl md:text-5xl font-black text-slate-900 tracking-tighter">Designed for Discovery</h2>
            <p className="text-slate-500 font-medium text-lg">Features engineered specifically for the modern academic workflow.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-3xl border hover:shadow-xl transition-all group">
              <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-all">
                <Share2 className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">Visual Abstracts</h3>
              <p className="text-slate-500 leading-relaxed font-medium">Turn complex methodologies into high-impact visual stories that peers actually read.</p>
            </div>

            <div className="bg-white p-8 rounded-3xl border hover:shadow-xl transition-all group">
              <div className="w-14 h-14 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-green-600 group-hover:text-white transition-all">
                <GraduationCap className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">Scholarship Access</h3>
              <p className="text-slate-500 leading-relaxed font-medium">Browse thousands of grants and funded opportunities specifically matched to your expertise.</p>
            </div>

            <div className="bg-white p-8 rounded-3xl border hover:shadow-xl transition-all group">
              <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                <Users className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">Institution Search</h3>
              <p className="text-slate-500 leading-relaxed font-medium">Map your path to the world's most prestigious labs and collaborative environments.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 border-t">
        <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-10">
          <div className="space-y-4 text-center md:text-left">
            <div className="flex items-center gap-2 justify-center md:justify-start">
              <Microscope className="w-6 h-6 text-blue-600" />
              <span className="text-2xl font-black text-slate-900 tracking-tighter">SciLens</span>
            </div>
            <p className="text-slate-500 font-medium max-w-xs">Building the global nervous system of human innovation.</p>
          </div>
          <div className="flex gap-10">
            <div className="space-y-3">
              <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">App</h4>
              <ul className="space-y-2 text-sm font-bold text-slate-700">
                <li className="hover:text-blue-600 cursor-pointer">Manifesto</li>
                <li className="hover:text-blue-600 cursor-pointer">Security</li>
                <li className="hover:text-blue-600 cursor-pointer">API</li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">Connect</h4>
              <ul className="space-y-2 text-sm font-bold text-slate-700">
                <li className="hover:text-blue-600 cursor-pointer">Twitter</li>
                <li className="hover:text-blue-600 cursor-pointer">LinkedIn</li>
                <li className="hover:text-blue-600 cursor-pointer">Discord</li>
              </ul>
            </div>
          </div>
        </div>
        <div className="max-w-6xl mx-auto px-6 pt-10 text-center">
          <p className="text-[10px] font-bold text-slate-300 uppercase tracking-[0.2em]">© 2025 SciLens. All Scientific Rights Reserved.</p>
        </div>
      </footer>
    </div>
  );
};

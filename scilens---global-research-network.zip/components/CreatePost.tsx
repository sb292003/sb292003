
import React, { useState } from 'react';
import { Camera, Image as ImageIcon, Send, Sparkles, X, Microscope, Check, RotateCcw } from 'lucide-react';
import { ResearchField } from '../types';
import { summarizeResearch } from '../services/geminiService';

interface CreatePostProps {
  onPublish: (title: string, abstract: string, image: string, field: ResearchField) => void;
}

export const CreatePost: React.FC<CreatePostProps> = ({ onPublish }) => {
  const [title, setTitle] = useState('');
  const [abstract, setAbstract] = useState('');
  const [field, setField] = useState<ResearchField>(ResearchField.PHYSICS);
  const [preview, setPreview] = useState<string | null>(null);
  
  // AI Refinement State
  const [generatedAiSummary, setGeneratedAiSummary] = useState<string>('');
  const [isRefining, setIsRefining] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleRefine = async () => {
    if (!title || !abstract) return;
    setIsRefining(true);
    try {
      const summary = await summarizeResearch(title, abstract);
      setGeneratedAiSummary(summary);
    } catch (error) {
      console.error("Error refining abstract:", error);
    } finally {
      setIsRefining(false);
    }
  };

  const applyAiSummary = () => {
    setAbstract(generatedAiSummary);
    setGeneratedAiSummary('');
  };

  const handlePublish = () => {
    if (!title || !abstract || !preview) return;
    onPublish(title, abstract, preview, field);
    setTitle('');
    setAbstract('');
    setPreview(null);
    setGeneratedAiSummary('');
  };

  return (
    <div className="bg-white border rounded-2xl shadow-sm overflow-hidden p-6 space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
          <Microscope className="w-6 h-6" />
        </div>
        <h2 className="text-xl font-bold text-slate-900">Publish Research</h2>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Field of Study</label>
          <select 
            value={field}
            onChange={(e) => setField(e.target.value as ResearchField)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none transition-all"
          >
            {Object.values(ResearchField).map(f => <option key={f} value={f}>{f}</option>)}
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Paper Title / Headline</label>
          <input 
            type="text" 
            placeholder="e.g., Novel findings in high-density energy storage"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none transition-all"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Scientific Abstract</label>
          <textarea 
            rows={4}
            placeholder="Describe your breakthrough, methodology, and results..."
            value={abstract}
            onChange={(e) => setAbstract(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none transition-all resize-none"
          />
        </div>

        {/* AI Summary Suggestion Box */}
        {generatedAiSummary && (
          <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 animate-in fade-in slide-in-from-top-2 duration-300">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2 text-blue-700 text-[10px] font-bold uppercase tracking-wider">
                <Sparkles className="w-3 h-3" />
                AI Refined Suggestion
              </div>
              <button 
                onClick={() => setGeneratedAiSummary('')}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-sm text-slate-700 leading-relaxed mb-4 italic">
              "{generatedAiSummary}"
            </p>
            <div className="flex gap-2">
              <button 
                onClick={applyAiSummary}
                className="flex items-center gap-1.5 bg-blue-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-blue-700 transition-colors"
              >
                <Check className="w-3 h-3" />
                Apply to Abstract
              </button>
              <button 
                onClick={() => setGeneratedAiSummary('')}
                className="flex items-center gap-1.5 bg-white border border-slate-200 text-slate-600 px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-slate-50 transition-colors"
              >
                <RotateCcw className="w-3 h-3" />
                Dismiss
              </button>
            </div>
          </div>
        )}

        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Primary Figure / Graphic</label>
          <div className="relative group">
            {preview ? (
              <div className="relative rounded-xl overflow-hidden border aspect-video">
                <img src={preview} alt="Preview" className="w-full h-full object-cover" />
                <button 
                  onClick={() => setPreview(null)}
                  className="absolute top-2 right-2 bg-black/50 text-white p-1 rounded-full hover:bg-black/70 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center border-2 border-dashed border-slate-200 rounded-xl aspect-video cursor-pointer hover:bg-slate-50 hover:border-blue-400 transition-all">
                <ImageIcon className="w-10 h-10 text-slate-300 mb-2" />
                <span className="text-sm text-slate-500 font-medium">Click to upload research graphic</span>
                <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
              </label>
            )}
          </div>
        </div>
      </div>

      <div className="flex gap-4 pt-4 border-t">
        <button 
          onClick={handleRefine}
          disabled={isRefining || !title || !abstract}
          className="flex-1 flex items-center justify-center gap-2 bg-slate-100 text-slate-600 px-4 py-3 rounded-xl font-bold text-sm hover:bg-slate-200 transition-all disabled:opacity-50"
        >
          <Sparkles className={`w-4 h-4 ${isRefining ? 'animate-pulse' : ''}`} />
          {isRefining ? 'Summarizing...' : 'Refine with AI'}
        </button>
        <button 
          onClick={handlePublish}
          disabled={!title || !abstract || !preview || isRefining}
          className="flex-1 flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-3 rounded-xl font-bold text-sm hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 disabled:opacity-50 disabled:shadow-none"
        >
          <Send className="w-4 h-4" />
          Publish Work
        </button>
      </div>
    </div>
  );
};


import React, { useState } from 'react';
import { X, Mail, Phone, Globe, Chrome, Fingerprint, ArrowRight, Loader2 } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onLogin }) => {
  const [method, setMethod] = useState<'options' | 'email' | 'phone'>('options');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSocialLogin = (platform: string) => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      onLogin();
    }, 1500);
  };

  const renderOptions = () => (
    <div className="space-y-3">
      <button 
        onClick={() => setMethod('email')}
        className="w-full flex items-center gap-3 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl hover:bg-slate-100 transition-all font-semibold text-slate-700"
      >
        <Mail className="w-5 h-5 text-blue-600" />
        Continue with Email
      </button>
      <button 
        onClick={() => setMethod('phone')}
        className="w-full flex items-center gap-3 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl hover:bg-slate-100 transition-all font-semibold text-slate-700"
      >
        <Phone className="w-5 h-5 text-green-600" />
        Continue with Phone
      </button>
      
      <div className="relative py-4">
        <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
        <div className="relative flex justify-center text-xs uppercase"><span className="bg-white px-2 text-slate-400 font-bold tracking-widest">Institutional / Social</span></div>
      </div>

      <button 
        onClick={() => handleSocialLogin('Google')}
        className="w-full flex items-center gap-3 px-4 py-3 bg-white border border-slate-200 rounded-xl hover:shadow-md transition-all font-semibold text-slate-700"
      >
        <Chrome className="w-5 h-5 text-red-500" />
        Sign in with Google
      </button>
      
      <button 
        onClick={() => handleSocialLogin('ORCID')}
        className="w-full flex items-center gap-3 px-4 py-3 bg-[#A6CE39] text-white rounded-xl hover:opacity-90 transition-all font-bold shadow-lg shadow-[#A6CE39]/20"
      >
        <div className="w-5 h-5 flex items-center justify-center bg-white rounded-sm">
          <span className="text-[#A6CE39] text-[10px] font-black">iD</span>
        </div>
        Connect with ORCID iD
      </button>
    </div>
  );

  const renderEmail = () => (
    <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
      <div className="space-y-1">
        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Work Email</label>
        <input 
          type="email" 
          placeholder="professor@university.edu"
          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all"
          autoFocus
        />
      </div>
      <button 
        onClick={() => handleSocialLogin('Email')}
        className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2"
      >
        Send Access Link <ArrowRight className="w-4 h-4" />
      </button>
      <button onClick={() => setMethod('options')} className="w-full text-slate-400 text-sm font-bold hover:text-slate-600">Back to options</button>
    </div>
  );

  const renderPhone = () => (
    <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
      <div className="space-y-1">
        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Phone Number</label>
        <div className="flex gap-2">
          <div className="w-20 px-3 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-400 text-sm flex items-center justify-center font-bold">+1</div>
          <input 
            type="tel" 
            placeholder="555-0123"
            className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all"
            autoFocus
          />
        </div>
      </div>
      <button 
        onClick={() => handleSocialLogin('Phone')}
        className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2"
      >
        Verify via SMS <ArrowRight className="w-4 h-4" />
      </button>
      <button onClick={() => setMethod('options')} className="w-full text-slate-400 text-sm font-bold hover:text-slate-600">Back to options</button>
    </div>
  );

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative bg-white w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        {isLoading && (
          <div className="absolute inset-0 z-50 bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center gap-3">
            <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
            <p className="font-bold text-slate-900 text-sm uppercase tracking-widest">Verifying Identity...</p>
          </div>
        )}
        
        <div className="p-6 pb-4 flex items-center justify-between border-b">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Researcher Access</h2>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Join SciLens Network</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full text-slate-400 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {method === 'options' && renderOptions()}
          {method === 'email' && renderEmail()}
          {method === 'phone' && renderPhone()}
        </div>

        <div className="p-6 pt-0 bg-slate-50/50">
          <p className="text-[10px] text-center text-slate-400 leading-relaxed font-medium">
            By continuing, you agree to the <a href="#" className="underline">SciLens Peer Review Agreement</a> and 
            <a href="#" className="underline"> Data Ethics Policy</a>.
          </p>
        </div>
      </div>
    </div>
  );
};


import React, { useEffect, useState } from 'react';
import { Search, ExternalLink, Sparkles, TrendingUp } from 'lucide-react';
import { getTrendingResearch } from '../services/geminiService';
import { ResearchField } from '../types';

export const TrendingSidebar: React.FC = () => {
  const [trending, setTrending] = useState<{text: string, sources: any[]} | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchTrending = async () => {
      setLoading(true);
      const data = await getTrendingResearch(ResearchField.PHYSICS);
      if (data) setTrending(data);
      setLoading(false);
    };
    fetchTrending();
  }, []);

  return (
    <div className="hidden lg:block w-80 fixed right-[calc(50%-600px)] top-8 space-y-6">
      <div className="bg-white border rounded-2xl p-4 shadow-sm">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search disciplines..." 
            className="w-full bg-slate-50 border border-slate-100 rounded-full pl-10 pr-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>
      </div>

      <div className="bg-white border rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex items-center gap-2 text-slate-900">
          <Sparkles className="w-4 h-4 text-blue-600" />
          <h3 className="font-bold text-sm uppercase tracking-widest">Global Trends</h3>
        </div>

        {loading ? (
          <div className="space-y-3 animate-pulse">
            <div className="h-4 bg-slate-100 rounded w-full"></div>
            <div className="h-4 bg-slate-100 rounded w-3/4"></div>
            <div className="h-20 bg-slate-50 rounded w-full"></div>
          </div>
        ) : trending ? (
          <div className="space-y-4">
            <div className="text-sm text-slate-600 leading-relaxed whitespace-pre-wrap italic">
              {trending.text}
            </div>
            
            <div className="pt-4 border-t space-y-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Scientific Sources</span>
              {trending.sources.slice(0, 3).map((chunk: any, i: number) => (
                <a 
                  key={i} 
                  href={chunk.web?.uri} 
                  target="_blank" 
                  className="flex items-center justify-between group"
                >
                  <span className="text-xs text-blue-600 font-medium truncate max-w-[180px] group-hover:underline">
                    {chunk.web?.title || 'Research Journal'}
                  </span>
                  <ExternalLink className="w-3 h-3 text-slate-300 group-hover:text-blue-500" />
                </a>
              ))}
            </div>
          </div>
        ) : (
          <p className="text-xs text-slate-400">Unable to load trends</p>
        )}
      </div>

      <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl p-5 text-white shadow-xl shadow-blue-500/20">
        <h4 className="font-bold text-lg mb-2">SciLens Lab</h4>
        <p className="text-xs text-blue-100 mb-4 leading-relaxed">
          Access specialized data analysis tools and AI agents to accelerate your publication workflow.
        </p>
        <button className="w-full bg-white/20 backdrop-blur hover:bg-white/30 text-white font-bold py-2 rounded-xl text-sm transition-colors">
          Join Beta
        </button>
      </div>

      <div className="px-4 text-[10px] text-slate-400 flex flex-wrap gap-x-4 gap-y-2 uppercase font-bold tracking-widest">
        <a href="#" className="hover:text-slate-600">Ethics</a>
        <a href="#" className="hover:text-slate-600">Guidelines</a>
        <a href="#" className="hover:text-slate-600">Peer Review</a>
        <a href="#" className="hover:text-slate-600">Privacy</a>
        <span>© 2024 SciLens Corp</span>
      </div>
    </div>
  );
};

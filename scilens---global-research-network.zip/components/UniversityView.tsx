
import React, { useState, useMemo } from 'react';
import { MOCK_UNIVERSITIES } from '../constants';
import { MapPin, BookOpen, Award, Users, Search, Globe } from 'lucide-react';
import { University } from '../types';

export const UniversityView: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('All Countries');

  const countries = useMemo(() => {
    const list = Array.from(new Set(MOCK_UNIVERSITIES.map(u => u.country)));
    return ['All Countries', ...list.sort()];
  }, []);

  const filteredUniversities = useMemo(() => {
    return MOCK_UNIVERSITIES.filter(uni => {
      const matchesSearch = uni.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            uni.location.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCountry = selectedCountry === 'All Countries' || uni.country === selectedCountry;
      return matchesSearch && matchesCountry;
    });
  }, [searchQuery, selectedCountry]);

  // Grouping logic
  const groupedUniversities = useMemo(() => {
    const groups: Record<string, University[]> = {};
    filteredUniversities.forEach(uni => {
      if (!groups[uni.country]) groups[uni.country] = [];
      groups[uni.country].push(uni);
    });
    return groups;
  }, [filteredUniversities]);

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col gap-1 mb-4">
        <h2 className="text-2xl font-bold text-slate-900">Partner Institutions</h2>
        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Global Academic Network</p>
      </div>

      {/* Search and Filter Bar */}
      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input 
            type="text"
            placeholder="Search university name or city..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all shadow-sm"
          />
        </div>
        <div className="relative md:w-48">
          <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <select
            value={selectedCountry}
            onChange={(e) => setSelectedCountry(e.target.value)}
            className="w-full pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all shadow-sm appearance-none"
          >
            {countries.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </div>

      {Object.entries(groupedUniversities).sort().map(([country, unis]) => (
        <div key={country} className="space-y-4">
          <div className="flex items-center gap-3 px-1">
            <span className="text-sm font-black text-slate-400 uppercase tracking-tighter">{country}</span>
            <div className="h-px flex-1 bg-slate-100" />
            <span className="text-[10px] font-bold text-slate-300 uppercase">{unis.length} Units</span>
          </div>
          
          <div className="grid grid-cols-1 gap-6">
            {unis.map((uni) => (
              <div key={uni.id} className="bg-white border rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow flex flex-col md:flex-row gap-6 group">
                <div className="relative">
                    <img src={uni.logo} alt={uni.name} className="w-20 h-20 rounded-xl object-cover border group-hover:border-blue-200 transition-colors" />
                    <div className="absolute -top-2 -right-2 bg-blue-600 text-white text-[10px] font-black px-1.5 py-0.5 rounded shadow-sm">#{uni.ranking}</div>
                </div>
                <div className="flex-1 space-y-4">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 group-hover:text-blue-600 transition-colors">{uni.name}</h3>
                      <div className="flex items-center gap-2 text-slate-500 text-sm">
                        <MapPin className="w-4 h-4" />
                        {uni.location}, <span className="font-bold text-slate-400">{uni.country}</span>
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {uni.description}
                  </p>

                  <div className="flex flex-wrap gap-6 pt-2 border-t border-slate-50">
                    <div className="flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-slate-400" />
                      <span className="text-sm font-bold text-slate-900">{uni.researchCount.toLocaleString()} <span className="text-slate-500 font-medium">Papers</span></span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-slate-400" />
                      <span className="text-sm font-bold text-slate-900">12k+ <span className="text-slate-500 font-medium">Researchers</span></span>
                    </div>
                  </div>

                  <button className="w-full md:w-auto bg-slate-50 text-slate-700 hover:bg-blue-600 hover:text-white px-6 py-2 rounded-xl font-bold text-sm transition-all border border-slate-100">
                    Explore Laboratory
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}

      {Object.keys(groupedUniversities).length === 0 && (
        <div className="text-center py-20 bg-white border border-dashed rounded-3xl">
          <p className="text-slate-400 font-medium">No institutions found matching your criteria.</p>
          <button onClick={() => {setSearchQuery(''); setSelectedCountry('All Countries')}} className="mt-2 text-blue-600 font-bold">Clear Filters</button>
        </div>
      )}
    </div>
  );
};


import React, { useState } from 'react';
import { Researcher, ResearchPost, ExternalPublication } from '../types';
import { PostCard } from './PostCard';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Award, BookOpen, Quote, TrendingUp, BadgeCheck, Microscope, Link2, Chrome, UserRoundSearch } from 'lucide-react';
import { ImportResearchModal } from './ImportResearchModal';

interface ProfileViewProps {
  researcher: Researcher;
  posts: ResearchPost[];
  onImportPost?: (pub: ExternalPublication) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ researcher, posts, onImportPost }) => {
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const chartData = [
    { name: '2021', cites: 1800 },
    { name: '2022', cites: 2400 },
    { name: '2023', cites: 3100 },
    { name: '2024', cites: 4500 },
  ];

  const getRoleDisplay = () => {
    if (researcher.role === 'PhD Scholar' && researcher.phdYear) {
      return `PhD Scholar (${researcher.phdYear})`;
    }
    return researcher.role;
  };

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700 pb-20">
      {/* Scientist Header Card */}
      <div className="bg-white border rounded-[2.5rem] p-8 md:p-12 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-5">
           <Microscope className="w-48 h-48 text-blue-900" />
        </div>

        <div className="flex flex-col md:flex-row gap-10 items-center md:items-start text-center md:text-left relative z-10">
          <div className="relative">
            <div className="w-32 h-32 md:w-44 md:h-44 rounded-full p-1.5 bg-gradient-to-tr from-blue-600 to-indigo-600 shadow-2xl">
              <img src={researcher.avatar} alt={researcher.name} className="w-full h-full rounded-full border-4 border-white object-cover" />
            </div>
            <div className="absolute -bottom-2 -right-2 bg-blue-600 text-white p-2.5 rounded-full border-4 border-white shadow-xl">
              <BadgeCheck className="w-6 h-6" />
            </div>
          </div>

          <div className="flex-1 space-y-6">
            <div>
              <div className="flex flex-col md:flex-row md:items-center gap-3 mb-2">
                <h1 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight leading-none">{researcher.name}</h1>
                <span className="inline-flex items-center px-4 py-1.5 rounded-full text-xs font-black bg-blue-50 text-blue-600 border border-blue-100 shadow-sm">
                  {getRoleDisplay()}
                </span>
              </div>
              <p className="text-xl text-slate-600 font-semibold">{researcher.title}</p>
              <p className="text-slate-400 font-bold uppercase text-xs tracking-[0.2em] mt-1">{researcher.institution}</p>
            </div>
            
            <div className="flex flex-wrap justify-center md:justify-start gap-3">
              <button 
                onClick={() => setIsImportModalOpen(true)}
                className="flex items-center gap-2.5 bg-[#A6CE39] text-white px-6 py-3 rounded-2xl font-black text-xs hover:opacity-90 transition-all shadow-lg shadow-[#A6CE39]/20"
              >
                <div className="w-4 h-4 flex items-center justify-center bg-white rounded-sm">
                  <span className="text-[#A6CE39] text-[8px] font-black">iD</span>
                </div>
                Connect ORCID
              </button>
              <button 
                onClick={() => setIsImportModalOpen(true)}
                className="flex items-center gap-2.5 bg-white border border-slate-200 text-slate-700 px-6 py-3 rounded-2xl font-black text-xs hover:bg-slate-50 transition-all"
              >
                <Chrome className="w-4 h-4 text-blue-600" />
                Google Scholar
              </button>
              <button className="bg-slate-900 text-white px-8 py-3 rounded-2xl font-black text-xs hover:bg-blue-600 transition-all shadow-xl shadow-slate-900/10">Follow Lab</button>
            </div>

            <div className="flex gap-12 justify-center md:justify-start pt-4 border-t border-slate-50">
              <div className="text-center">
                <div className="text-2xl font-black text-slate-900">{researcher.publications}</div>
                <div className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Papers</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-black text-slate-900">{researcher.citations.toLocaleString()}</div>
                <div className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Citations</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-black text-slate-900">{researcher.hIndex}</div>
                <div className="text-[10px] text-slate-400 font-black uppercase tracking-widest">H-Index</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <ImportResearchModal 
        isOpen={isImportModalOpen} 
        onClose={() => setIsImportModalOpen(false)} 
        onImport={(pub) => {
          onImportPost?.(pub);
          setIsImportModalOpen(false);
        }}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white border rounded-[2rem] p-8 shadow-sm">
          <div className="flex items-center gap-3 mb-8">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            <h2 className="font-black text-slate-900 uppercase tracking-widest text-[10px]">Citation Impact</h2>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 'bold'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 'bold'}} />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)' }}
                  cursor={{ fill: '#f8fafc' }}
                />
                <Bar dataKey="cites" fill="#2563eb" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-[2rem] p-8 text-white shadow-xl shadow-slate-900/10">
            <h3 className="text-lg font-black mb-2 tracking-tight">Open for Collaboration</h3>
            <p className="text-sm text-slate-300 font-medium leading-relaxed">Currently seeking PhD candidates for the 2026 Quantum Dynamics intake. Interests in topological insulators.</p>
            <button className="mt-6 bg-blue-600 text-white px-6 py-3 rounded-2xl font-black text-xs hover:bg-blue-500 transition-all">Send Inquiry</button>
          </div>
          <div className="bg-blue-50 border border-blue-100 rounded-[2rem] p-8">
            <div className="flex items-center gap-3 mb-2">
              <Award className="w-5 h-5 text-blue-600" />
              <h4 className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Latest Honor</h4>
            </div>
            <p className="text-sm font-bold text-slate-900">Wolf Prize in Physics (2024)</p>
            <p className="text-xs text-slate-500 font-medium mt-1">For pioneering work in cold atom systems.</p>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="flex items-center gap-3 px-4">
          <BookOpen className="w-6 h-6 text-slate-400" />
          <h2 className="font-black text-slate-900 uppercase tracking-[0.2em] text-xs">Visual Lab Records</h2>
        </div>
        <div className="grid grid-cols-1 gap-8">
          {posts.map(post => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      </div>
    </div>
  );
};


export enum ResearchField {
  ALL = 'All Fields',
  PHYSICS = 'Physics',
  BIOLOGY = 'Biology',
  CHEMISTRY = 'Chemistry',
  COMPUTER_SCIENCE = 'Computer Science',
  MATHEMATICS = 'Mathematics',
  MEDICINE = 'Medicine',
  ENVIRONMENTAL = 'Environmental Science'
}

export type ResearcherRole = 
  | 'Graduate Student'
  | 'Post Graduate Student'
  | 'PhD Scholar'
  | 'Associate Professor'
  | 'Assistant Professor'
  | 'Professor'
  | 'Scientist'
  | 'Individual Researcher';

export interface Researcher {
  id: string;
  name: string;
  title: string;
  institution: string;
  avatar: string;
  hIndex: number;
  citations: number;
  publications: number;
  following: number;
  followers: number;
  role: ResearcherRole;
  phdYear?: string;
  orcidId?: string;
  scholarId?: string;
}

export interface ExternalPublication {
  id: string;
  title: string;
  authors: string[];
  year: string;
  journal: string;
  doi?: string;
  url?: string;
  snippet?: string;
}

export interface ResearchPost {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorRole: ResearcherRole;
  title: string;
  abstract: string;
  imageUrl: string;
  field: ResearchField;
  endorsements: number;
  citations: number;
  comments: number;
  shares: number;
  timestamp: string;
  doi?: string;
  aiSummary?: string;
}

export interface University {
  id: string;
  name: string;
  location: string;
  country: string;
  logo: string;
  researchCount: number;
  ranking: number;
  description: string;
}

export interface Scholarship {
  id: string;
  title: string;
  platform: string;
  amount: string;
  eligibleCountries: string[];
  deadline: string;
  description: string;
  link: string;
  category: 'Full' | 'Partial' | 'Grant';
}

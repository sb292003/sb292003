
import { ResearchField, ResearchPost, Researcher, University, Scholarship } from './types';

export const MOCK_UNIVERSITIES: University[] = [
  {
    id: 'u1',
    name: 'MIT - Massachusetts Institute of Technology',
    location: 'Cambridge, MA',
    country: 'USA',
    logo: 'https://picsum.photos/seed/mit/200/200',
    researchCount: 15400,
    ranking: 1,
    description: 'Leading the world in quantum computing and aerospace engineering.'
  },
  {
    id: 'u2',
    name: 'Stanford University',
    location: 'Stanford, CA',
    country: 'USA',
    logo: 'https://picsum.photos/seed/stanford/200/200',
    researchCount: 12800,
    ranking: 3,
    description: 'At the forefront of AI research and biotechnology.'
  },
  {
    id: 'u3',
    name: 'ETH Zurich',
    location: 'Zurich, Switzerland',
    country: 'Switzerland',
    logo: 'https://picsum.photos/seed/eth/200/200',
    researchCount: 9200,
    ranking: 7,
    description: 'Specializing in robotics, material science, and civil engineering.'
  },
  {
    id: 'u4',
    name: 'University of Oxford',
    location: 'Oxford, UK',
    country: 'United Kingdom',
    logo: 'https://picsum.photos/seed/oxford/200/200',
    researchCount: 14000,
    ranking: 4,
    description: 'World-renowned center for humanities and social sciences research.'
  },
  {
    id: 'u5',
    name: 'Technical University of Munich',
    location: 'Munich, Germany',
    country: 'Germany',
    logo: 'https://picsum.photos/seed/tum/200/200',
    researchCount: 8500,
    ranking: 37,
    description: 'Premier technical university focused on engineering and technology.'
  },
  {
    id: 'u6',
    name: 'University of Tokyo',
    location: 'Tokyo, Japan',
    country: 'Japan',
    logo: 'https://picsum.photos/seed/tokyo/200/200',
    researchCount: 11000,
    ranking: 23,
    description: 'Leading research university in Asia across all major disciplines.'
  }
];

export const MOCK_SCHOLARSHIPS: Scholarship[] = [
  {
    id: 's1',
    title: 'Fulbright Program',
    platform: 'US Department of State',
    amount: 'Fully Funded',
    eligibleCountries: ['USA', 'International'],
    deadline: 'Oct 2025',
    description: 'Grant for international educational exchange for students, scholars, teachers, professionals, scientists and artists.',
    link: 'https://fulbrightprogram.org',
    category: 'Full'
  },
  {
    id: 's2',
    title: 'Chevening Scholarships',
    platform: 'UK Foreign Office',
    amount: 'Fully Funded',
    eligibleCountries: ['United Kingdom', 'International'],
    deadline: 'Nov 2025',
    description: 'Global scholarship program of the UK government, offered to people who show potential to become future leaders.',
    link: 'https://chevening.org',
    category: 'Full'
  },
  {
    id: 's3',
    title: 'DAAD Research Grants',
    platform: 'DAAD Germany',
    amount: '€1,200/mo + Travel',
    eligibleCountries: ['Germany', 'International'],
    deadline: 'Year-round',
    description: 'Supports international students and researchers in Germany across all academic disciplines.',
    link: 'https://daad.de',
    category: 'Grant'
  },
  {
    id: 's4',
    title: 'MEXT Scholarship',
    platform: 'Japanese Government',
    amount: 'Full Tuition + Stipend',
    eligibleCountries: ['Japan', 'International'],
    deadline: 'May 2025',
    description: 'The Ministry of Education, Culture, Sports, Science and Technology (MEXT) of Japan offers scholarships for study in Japan.',
    link: 'https://studyinjapan.go.jp',
    category: 'Full'
  }
];

export const MOCK_RESEARCHERS: Researcher[] = [
  {
    id: 'r1',
    name: 'Dr. Elena Vance',
    title: 'Lead Researcher in Quantum Dynamics',
    institution: 'MIT',
    avatar: 'https://picsum.photos/seed/elena/200/200',
    hIndex: 42,
    citations: 12500,
    publications: 156,
    following: 120,
    followers: 4500,
    role: 'Professor'
  },
  {
    id: 'r2',
    name: 'Sarah Jenkins',
    title: 'Neuroscience Laboratory',
    institution: 'Stanford',
    avatar: 'https://picsum.photos/seed/sarah/200/200',
    hIndex: 12,
    citations: 800,
    publications: 15,
    following: 340,
    followers: 2100,
    role: 'PhD Scholar',
    phdYear: '3rd Year'
  }
];

export const MOCK_POSTS: ResearchPost[] = [
  {
    id: 'p1',
    authorId: 'r1',
    authorName: 'Dr. Elena Vance',
    authorAvatar: 'https://picsum.photos/seed/elena/200/200',
    authorRole: 'Professor',
    title: 'Observation of Topological Phonon Polaritons',
    abstract: 'We report the first direct observation of topological phonon polaritons in a van der Waals heterostructure. This breakthrough allows for sub-diffraction light control with minimal loss.',
    imageUrl: 'https://picsum.photos/seed/physics1/800/600',
    field: ResearchField.PHYSICS,
    endorsements: 1240,
    citations: 45,
    comments: 89,
    shares: 450,
    timestamp: '2h ago',
    doi: '10.1038/s41586-024-00000-0'
  },
  {
    id: 'p2',
    authorId: 'r2',
    authorName: 'Sarah Jenkins',
    authorAvatar: 'https://picsum.photos/seed/sarah/200/200',
    authorRole: 'PhD Scholar',
    title: 'CRISPR-Modified Neural Pathways',
    abstract: 'Using advanced gene editing, we have successfully restored synaptic plasticity in murine models of neurodegeneration. This opens new avenues for Alzheimers treatment.',
    imageUrl: 'https://picsum.photos/seed/bio1/800/600',
    field: ResearchField.BIOLOGY,
    endorsements: 3500,
    citations: 128,
    comments: 210,
    shares: 890,
    timestamp: '5h ago',
    doi: '10.1126/science.ade0000'
  }
];

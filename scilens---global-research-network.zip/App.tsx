
import React, { useState, useMemo } from 'react';
import { Layout } from './components/Layout';
import { PostCard } from './components/PostCard';
import { ProfileView } from './components/ProfileView';
import { CreatePost } from './components/CreatePost';
import { UniversityView } from './components/UniversityView';
import { ScholarshipView } from './components/ScholarshipView';
import { TrendingSidebar } from './components/TrendingSidebar';
import { LandingPage } from './components/LandingPage';
import { AuthModal } from './components/AuthModal';
import { MOCK_POSTS, MOCK_RESEARCHERS } from './constants';
import { ResearchPost, ResearchField, ExternalPublication } from './types';

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('feed');
  const [posts, setPosts] = useState<ResearchPost[]>(MOCK_POSTS);
  const [selectedField, setSelectedField] = useState<ResearchField>(ResearchField.ALL);

  const handlePublish = (title: string, abstract: string, image: string, field: ResearchField) => {
    const newPost: ResearchPost = {
      id: `p${Date.now()}`,
      authorId: 'r_current',
      authorName: 'Dr. Elena Vance',
      authorAvatar: MOCK_RESEARCHERS[0].avatar,
      authorRole: 'Professor',
      title,
      abstract,
      imageUrl: image,
      field,
      endorsements: 0,
      citations: 0,
      comments: 0,
      shares: 0,
      timestamp: 'Just now'
    };
    setPosts([newPost, ...posts]);
    setActiveTab('feed');
  };

  const handleImportPost = (pub: ExternalPublication) => {
    const newPost: ResearchPost = {
      id: `imported-${pub.id}-${Date.now()}`,
      authorId: 'r1',
      authorName: MOCK_RESEARCHERS[0].name,
      authorAvatar: MOCK_RESEARCHERS[0].avatar,
      authorRole: MOCK_RESEARCHERS[0].role,
      title: pub.title,
      abstract: pub.snippet || `Breakthrough work published in ${pub.journal} (${pub.year}).`,
      imageUrl: `https://picsum.photos/seed/${pub.id}/1200/800`,
      field: ResearchField.PHYSICS,
      endorsements: 0,
      citations: 0,
      comments: 0,
      shares: 0,
      timestamp: 'Imported'
    };
    setPosts([newPost, ...posts]);
    setActiveTab('feed');
    // Scroll to top to see the new import
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const filteredPosts = useMemo(() => {
    if (selectedField === ResearchField.ALL) return posts;
    return posts.filter(post => post.field === selectedField);
  }, [posts, selectedField]);

  const renderContent = () => {
    switch (activeTab) {
      case 'feed':
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="flex flex-col gap-6">
              <div className="flex flex-col gap-1 px-4 md:px-0">
                <h2 className="text-3xl font-black text-slate-900 tracking-tight">The Frontier</h2>
                <p className="text-[10px] font-black text-blue-600 uppercase tracking-[0.3em]">Latest Verified Discoveries</p>
              </div>

              <div className="flex gap-2 overflow-x-auto pb-4 no-scrollbar -mx-4 px-4">
                {Object.values(ResearchField).map((field) => (
                  <button
                    key={field}
                    onClick={() => setSelectedField(field)}
                    className={`whitespace-nowrap px-6 py-2.5 rounded-2xl text-xs font-black transition-all border-2 ${
                      selectedField === field 
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xl shadow-blue-500/20' 
                        : 'bg-white text-slate-500 border-slate-100 hover:border-slate-200 shadow-sm'
                    }`}
                  >
                    {field}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-12">
              {filteredPosts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          </div>
        );
      case 'universities':
        return <UniversityView />;
      case 'scholarships':
        return <ScholarshipView />;
      case 'profile':
        return (
          <ProfileView 
            researcher={MOCK_RESEARCHERS[0]} 
            posts={posts.filter(p => p.authorId === 'r1' || p.authorId === 'r_current')} 
            onImportPost={handleImportPost}
          />
        );
      case 'post':
        return <CreatePost onPublish={handlePublish} />;
      default:
        return (
          <div className="py-20 text-center text-slate-400 font-black uppercase tracking-widest text-xs">
            Module under Peer Review
          </div>
        );
    }
  };

  if (!isLoggedIn) {
    return (
      <>
        <LandingPage onJoin={() => setIsAuthModalOpen(true)} />
        <AuthModal 
          isOpen={isAuthModalOpen} 
          onClose={() => setIsAuthModalOpen(false)} 
          onLogin={() => setIsLoggedIn(true)} 
        />
      </>
    );
  }

  return (
    <div className="relative selection:bg-blue-100">
      <Layout activeTab={activeTab} onTabChange={setActiveTab}>
        {renderContent()}
      </Layout>
      <TrendingSidebar />
    </div>
  );
};

export default App;


import { GoogleGenAI, Type } from "@google/genai";
import { ExternalPublication } from "../types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const summarizeResearch = async (title: string, abstract: string): Promise<string> => {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: `You are a world-class science communicator. Summarize this research in 2-3 engaging, simplified sentences for a professional social network feed.
      Title: ${title}
      Abstract: ${abstract}`,
      config: {
        temperature: 0.6,
        thinkingConfig: { thinkingBudget: 4000 }
      }
    });
    return response.text || "Summary unavailable.";
  } catch (error) {
    console.error("Summarization error:", error);
    return "AI insight temporarily unavailable.";
  }
};

export const fetchExternalResearch = async (platform: 'ORCID' | 'Scholar', id: string): Promise<ExternalPublication[]> => {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Search for professional research publications associated with the ${platform} profile ID/Name: ${id}. 
      Return a clean list of papers including Title, Authors, Year, and Journal.`,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              title: { type: Type.STRING },
              authors: { type: Type.ARRAY, items: { type: Type.STRING } },
              year: { type: Type.STRING },
              journal: { type: Type.STRING },
              doi: { type: Type.STRING },
              snippet: { type: Type.STRING }
            },
            required: ["id", "title", "authors", "year", "journal"]
          }
        }
      }
    });
    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("External fetch error:", error);
    return [];
  }
};

export const getTrendingResearch = async (field: string) => {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `What are the top 3 trending scientific breakthroughs globally in ${field} for 2024-2025? Provide short headlines.`,
      config: { tools: [{ googleSearch: {} }] }
    });
    return {
      text: response.text,
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error) {
    return null;
  }
};
